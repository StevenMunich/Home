﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub




    '//-----------------DO NOT TOUCH




    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer





    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim ApptIDLabel As System.Windows.Forms.Label
        Dim PetIDLabel As System.Windows.Forms.Label
        Dim ApptTypeNumLabel As System.Windows.Forms.Label
        Dim ApptDateLabel As System.Windows.Forms.Label
        Dim NotesLabel As System.Windows.Forms.Label
        Dim EstChargeLabel As System.Windows.Forms.Label
        Dim ActualChargeLabel As System.Windows.Forms.Label
        Dim NextApptDateLabel As System.Windows.Forms.Label
        Dim VetTechNumLabel As System.Windows.Forms.Label
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.FFDataSet = New Database.FFDataSet()
        Me.AppointmentBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.AppointmentTableAdapter = New Database.FFDataSetTableAdapters.AppointmentTableAdapter()
        Me.TableAdapterManager = New Database.FFDataSetTableAdapters.TableAdapterManager()
        Me.AppointmentBindingNavigator = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorAddNewItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorCountItem = New System.Windows.Forms.ToolStripLabel()
        Me.BindingNavigatorDeleteItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveFirstItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMovePreviousItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorPositionItem = New System.Windows.Forms.ToolStripTextBox()
        Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorMoveNextItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveLastItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.AppointmentBindingNavigatorSaveItem = New System.Windows.Forms.ToolStripButton()
        Me.ApptIDTextBox = New System.Windows.Forms.TextBox()
        Me.PetIDTextBox = New System.Windows.Forms.TextBox()
        Me.ApptTypeNumTextBox = New System.Windows.Forms.TextBox()
        Me.ApptDateDateTimePicker = New System.Windows.Forms.DateTimePicker()
        Me.NotesTextBox = New System.Windows.Forms.TextBox()
        Me.EstChargeTextBox = New System.Windows.Forms.TextBox()
        Me.ActualChargeTextBox = New System.Windows.Forms.TextBox()
        Me.NextApptDateDateTimePicker = New System.Windows.Forms.DateTimePicker()
        Me.VetTechNumTextBox = New System.Windows.Forms.TextBox()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.ApptIDDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PetIDDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ApptTypeNumDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ApptDateDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.NotesDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.EstChargeDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ActualChargeDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.NextApptDateDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.VetTechNumDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.AddNewButton = New System.Windows.Forms.Button()
        Me.SaveButton = New System.Windows.Forms.Button()
        Me.DeleteButton = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        ApptIDLabel = New System.Windows.Forms.Label()
        PetIDLabel = New System.Windows.Forms.Label()
        ApptTypeNumLabel = New System.Windows.Forms.Label()
        ApptDateLabel = New System.Windows.Forms.Label()
        NotesLabel = New System.Windows.Forms.Label()
        EstChargeLabel = New System.Windows.Forms.Label()
        ActualChargeLabel = New System.Windows.Forms.Label()
        NextApptDateLabel = New System.Windows.Forms.Label()
        VetTechNumLabel = New System.Windows.Forms.Label()
        CType(Me.FFDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.AppointmentBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.AppointmentBindingNavigator, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.AppointmentBindingNavigator.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'ApptIDLabel
        '
        ApptIDLabel.AutoSize = True
        ApptIDLabel.Location = New System.Drawing.Point(12, 50)
        ApptIDLabel.Name = "ApptIDLabel"
        ApptIDLabel.Size = New System.Drawing.Size(46, 13)
        ApptIDLabel.TabIndex = 1
        ApptIDLabel.Text = "Appt ID:"
        '
        'PetIDLabel
        '
        PetIDLabel.AutoSize = True
        PetIDLabel.Location = New System.Drawing.Point(12, 76)
        PetIDLabel.Name = "PetIDLabel"
        PetIDLabel.Size = New System.Drawing.Size(40, 13)
        PetIDLabel.TabIndex = 3
        PetIDLabel.Text = "Pet ID:"
        '
        'ApptTypeNumLabel
        '
        ApptTypeNumLabel.AutoSize = True
        ApptTypeNumLabel.Location = New System.Drawing.Point(12, 102)
        ApptTypeNumLabel.Name = "ApptTypeNumLabel"
        ApptTypeNumLabel.Size = New System.Drawing.Size(84, 13)
        ApptTypeNumLabel.TabIndex = 5
        ApptTypeNumLabel.Text = "Appt Type Num:"
        '
        'ApptDateLabel
        '
        ApptDateLabel.AutoSize = True
        ApptDateLabel.Location = New System.Drawing.Point(12, 129)
        ApptDateLabel.Name = "ApptDateLabel"
        ApptDateLabel.Size = New System.Drawing.Size(58, 13)
        ApptDateLabel.TabIndex = 7
        ApptDateLabel.Text = "Appt Date:"
        '
        'NotesLabel
        '
        NotesLabel.AutoSize = True
        NotesLabel.Location = New System.Drawing.Point(12, 154)
        NotesLabel.Name = "NotesLabel"
        NotesLabel.Size = New System.Drawing.Size(38, 13)
        NotesLabel.TabIndex = 9
        NotesLabel.Text = "Notes:"
        '
        'EstChargeLabel
        '
        EstChargeLabel.AutoSize = True
        EstChargeLabel.Location = New System.Drawing.Point(12, 180)
        EstChargeLabel.Name = "EstChargeLabel"
        EstChargeLabel.Size = New System.Drawing.Size(62, 13)
        EstChargeLabel.TabIndex = 11
        EstChargeLabel.Text = "Est Charge:"
        '
        'ActualChargeLabel
        '
        ActualChargeLabel.AutoSize = True
        ActualChargeLabel.Location = New System.Drawing.Point(12, 206)
        ActualChargeLabel.Name = "ActualChargeLabel"
        ActualChargeLabel.Size = New System.Drawing.Size(77, 13)
        ActualChargeLabel.TabIndex = 13
        ActualChargeLabel.Text = "Actual Charge:"
        '
        'NextApptDateLabel
        '
        NextApptDateLabel.AutoSize = True
        NextApptDateLabel.Location = New System.Drawing.Point(12, 233)
        NextApptDateLabel.Name = "NextApptDateLabel"
        NextApptDateLabel.Size = New System.Drawing.Size(83, 13)
        NextApptDateLabel.TabIndex = 15
        NextApptDateLabel.Text = "Next Appt Date:"
        '
        'VetTechNumLabel
        '
        VetTechNumLabel.AutoSize = True
        VetTechNumLabel.Location = New System.Drawing.Point(12, 258)
        VetTechNumLabel.Name = "VetTechNumLabel"
        VetTechNumLabel.Size = New System.Drawing.Size(79, 13)
        VetTechNumLabel.TabIndex = 17
        VetTechNumLabel.Text = "Vet Tech Num:"
        '
        'FFDataSet
        '
        Me.FFDataSet.DataSetName = "FFDataSet"
        Me.FFDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'AppointmentBindingSource
        '
        Me.AppointmentBindingSource.DataMember = "Appointment"
        Me.AppointmentBindingSource.DataSource = Me.FFDataSet
        '
        'AppointmentTableAdapter
        '
        Me.AppointmentTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.AppointmentTableAdapter = Me.AppointmentTableAdapter
        Me.TableAdapterManager.ApptTypeTableAdapter = Nothing
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.OwnerTableAdapter = Nothing
        Me.TableAdapterManager.PetTableAdapter = Nothing
        Me.TableAdapterManager.UpdateOrder = Database.FFDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        Me.TableAdapterManager.VetTableAdapter = Nothing
        Me.TableAdapterManager.VetTechTableAdapter = Nothing
        '
        'AppointmentBindingNavigator
        '
        Me.AppointmentBindingNavigator.AddNewItem = Me.BindingNavigatorAddNewItem
        Me.AppointmentBindingNavigator.BindingSource = Me.AppointmentBindingSource
        Me.AppointmentBindingNavigator.CountItem = Me.BindingNavigatorCountItem
        Me.AppointmentBindingNavigator.DeleteItem = Me.BindingNavigatorDeleteItem
        Me.AppointmentBindingNavigator.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem, Me.BindingNavigatorMovePreviousItem, Me.BindingNavigatorSeparator, Me.BindingNavigatorPositionItem, Me.BindingNavigatorCountItem, Me.BindingNavigatorSeparator1, Me.BindingNavigatorMoveNextItem, Me.BindingNavigatorMoveLastItem, Me.BindingNavigatorSeparator2, Me.BindingNavigatorAddNewItem, Me.BindingNavigatorDeleteItem, Me.AppointmentBindingNavigatorSaveItem})
        Me.AppointmentBindingNavigator.Location = New System.Drawing.Point(0, 0)
        Me.AppointmentBindingNavigator.MoveFirstItem = Me.BindingNavigatorMoveFirstItem
        Me.AppointmentBindingNavigator.MoveLastItem = Me.BindingNavigatorMoveLastItem
        Me.AppointmentBindingNavigator.MoveNextItem = Me.BindingNavigatorMoveNextItem
        Me.AppointmentBindingNavigator.MovePreviousItem = Me.BindingNavigatorMovePreviousItem
        Me.AppointmentBindingNavigator.Name = "AppointmentBindingNavigator"
        Me.AppointmentBindingNavigator.PositionItem = Me.BindingNavigatorPositionItem
        Me.AppointmentBindingNavigator.Size = New System.Drawing.Size(904, 25)
        Me.AppointmentBindingNavigator.TabIndex = 0
        Me.AppointmentBindingNavigator.Text = "BindingNavigator1"
        '
        'BindingNavigatorAddNewItem
        '
        Me.BindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorAddNewItem.Image = CType(resources.GetObject("BindingNavigatorAddNewItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorAddNewItem.Name = "BindingNavigatorAddNewItem"
        Me.BindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorAddNewItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorAddNewItem.Text = "Add new"
        '
        'BindingNavigatorCountItem
        '
        Me.BindingNavigatorCountItem.Name = "BindingNavigatorCountItem"
        Me.BindingNavigatorCountItem.Size = New System.Drawing.Size(35, 22)
        Me.BindingNavigatorCountItem.Text = "of {0}"
        Me.BindingNavigatorCountItem.ToolTipText = "Total number of items"
        '
        'BindingNavigatorDeleteItem
        '
        Me.BindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorDeleteItem.Image = CType(resources.GetObject("BindingNavigatorDeleteItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorDeleteItem.Name = "BindingNavigatorDeleteItem"
        Me.BindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorDeleteItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorDeleteItem.Text = "Delete"
        '
        'BindingNavigatorMoveFirstItem
        '
        Me.BindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveFirstItem.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveFirstItem.Name = "BindingNavigatorMoveFirstItem"
        Me.BindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveFirstItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveFirstItem.Text = "Move first"
        '
        'BindingNavigatorMovePreviousItem
        '
        Me.BindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMovePreviousItem.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMovePreviousItem.Name = "BindingNavigatorMovePreviousItem"
        Me.BindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMovePreviousItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMovePreviousItem.Text = "Move previous"
        '
        'BindingNavigatorSeparator
        '
        Me.BindingNavigatorSeparator.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorPositionItem
        '
        Me.BindingNavigatorPositionItem.AccessibleName = "Position"
        Me.BindingNavigatorPositionItem.AutoSize = False
        Me.BindingNavigatorPositionItem.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.BindingNavigatorPositionItem.Name = "BindingNavigatorPositionItem"
        Me.BindingNavigatorPositionItem.Size = New System.Drawing.Size(50, 23)
        Me.BindingNavigatorPositionItem.Text = "0"
        Me.BindingNavigatorPositionItem.ToolTipText = "Current position"
        '
        'BindingNavigatorSeparator1
        '
        Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator1"
        Me.BindingNavigatorSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorMoveNextItem
        '
        Me.BindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveNextItem.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveNextItem.Name = "BindingNavigatorMoveNextItem"
        Me.BindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveNextItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveNextItem.Text = "Move next"
        '
        'BindingNavigatorMoveLastItem
        '
        Me.BindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveLastItem.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveLastItem.Name = "BindingNavigatorMoveLastItem"
        Me.BindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveLastItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveLastItem.Text = "Move last"
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator2"
        Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'AppointmentBindingNavigatorSaveItem
        '
        Me.AppointmentBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.AppointmentBindingNavigatorSaveItem.Image = CType(resources.GetObject("AppointmentBindingNavigatorSaveItem.Image"), System.Drawing.Image)
        Me.AppointmentBindingNavigatorSaveItem.Name = "AppointmentBindingNavigatorSaveItem"
        Me.AppointmentBindingNavigatorSaveItem.Size = New System.Drawing.Size(23, 22)
        Me.AppointmentBindingNavigatorSaveItem.Text = "Save Data"
        '
        'ApptIDTextBox
        '
        Me.ApptIDTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.AppointmentBindingSource, "ApptID", True))
        Me.ApptIDTextBox.Location = New System.Drawing.Point(102, 47)
        Me.ApptIDTextBox.Name = "ApptIDTextBox"
        Me.ApptIDTextBox.Size = New System.Drawing.Size(200, 20)
        Me.ApptIDTextBox.TabIndex = 2
        '
        'PetIDTextBox
        '
        Me.PetIDTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.AppointmentBindingSource, "PetID", True))
        Me.PetIDTextBox.Location = New System.Drawing.Point(102, 73)
        Me.PetIDTextBox.Name = "PetIDTextBox"
        Me.PetIDTextBox.Size = New System.Drawing.Size(200, 20)
        Me.PetIDTextBox.TabIndex = 4
        '
        'ApptTypeNumTextBox
        '
        Me.ApptTypeNumTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.AppointmentBindingSource, "ApptTypeNum", True))
        Me.ApptTypeNumTextBox.Location = New System.Drawing.Point(102, 99)
        Me.ApptTypeNumTextBox.Name = "ApptTypeNumTextBox"
        Me.ApptTypeNumTextBox.Size = New System.Drawing.Size(200, 20)
        Me.ApptTypeNumTextBox.TabIndex = 6
        '
        'ApptDateDateTimePicker
        '
        Me.ApptDateDateTimePicker.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.AppointmentBindingSource, "ApptDate", True))
        Me.ApptDateDateTimePicker.Location = New System.Drawing.Point(102, 125)
        Me.ApptDateDateTimePicker.Name = "ApptDateDateTimePicker"
        Me.ApptDateDateTimePicker.Size = New System.Drawing.Size(200, 20)
        Me.ApptDateDateTimePicker.TabIndex = 8
        '
        'NotesTextBox
        '
        Me.NotesTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.AppointmentBindingSource, "Notes", True))
        Me.NotesTextBox.Location = New System.Drawing.Point(102, 151)
        Me.NotesTextBox.Name = "NotesTextBox"
        Me.NotesTextBox.Size = New System.Drawing.Size(200, 20)
        Me.NotesTextBox.TabIndex = 10
        '
        'EstChargeTextBox
        '
        Me.EstChargeTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.AppointmentBindingSource, "EstCharge", True))
        Me.EstChargeTextBox.Location = New System.Drawing.Point(102, 177)
        Me.EstChargeTextBox.Name = "EstChargeTextBox"
        Me.EstChargeTextBox.Size = New System.Drawing.Size(200, 20)
        Me.EstChargeTextBox.TabIndex = 12
        '
        'ActualChargeTextBox
        '
        Me.ActualChargeTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.AppointmentBindingSource, "ActualCharge", True))
        Me.ActualChargeTextBox.Location = New System.Drawing.Point(102, 203)
        Me.ActualChargeTextBox.Name = "ActualChargeTextBox"
        Me.ActualChargeTextBox.Size = New System.Drawing.Size(200, 20)
        Me.ActualChargeTextBox.TabIndex = 14
        '
        'NextApptDateDateTimePicker
        '
        Me.NextApptDateDateTimePicker.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.AppointmentBindingSource, "NextApptDate", True))
        Me.NextApptDateDateTimePicker.Location = New System.Drawing.Point(102, 229)
        Me.NextApptDateDateTimePicker.Name = "NextApptDateDateTimePicker"
        Me.NextApptDateDateTimePicker.Size = New System.Drawing.Size(200, 20)
        Me.NextApptDateDateTimePicker.TabIndex = 16
        '
        'VetTechNumTextBox
        '
        Me.VetTechNumTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.AppointmentBindingSource, "VetTechNum", True))
        Me.VetTechNumTextBox.Location = New System.Drawing.Point(102, 255)
        Me.VetTechNumTextBox.Name = "VetTechNumTextBox"
        Me.VetTechNumTextBox.Size = New System.Drawing.Size(200, 20)
        Me.VetTechNumTextBox.TabIndex = 18
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToOrderColumns = True
        Me.DataGridView1.AutoGenerateColumns = False
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.ApptIDDataGridViewTextBoxColumn, Me.PetIDDataGridViewTextBoxColumn, Me.ApptTypeNumDataGridViewTextBoxColumn, Me.ApptDateDataGridViewTextBoxColumn, Me.NotesDataGridViewTextBoxColumn, Me.EstChargeDataGridViewTextBoxColumn, Me.ActualChargeDataGridViewTextBoxColumn, Me.NextApptDateDataGridViewTextBoxColumn, Me.VetTechNumDataGridViewTextBoxColumn})
        Me.DataGridView1.DataSource = Me.AppointmentBindingSource
        Me.DataGridView1.Location = New System.Drawing.Point(402, 28)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(490, 345)
        Me.DataGridView1.TabIndex = 19
        '
        'ApptIDDataGridViewTextBoxColumn
        '
        Me.ApptIDDataGridViewTextBoxColumn.DataPropertyName = "ApptID"
        Me.ApptIDDataGridViewTextBoxColumn.HeaderText = "ApptID"
        Me.ApptIDDataGridViewTextBoxColumn.Name = "ApptIDDataGridViewTextBoxColumn"
        '
        'PetIDDataGridViewTextBoxColumn
        '
        Me.PetIDDataGridViewTextBoxColumn.DataPropertyName = "PetID"
        Me.PetIDDataGridViewTextBoxColumn.HeaderText = "PetID"
        Me.PetIDDataGridViewTextBoxColumn.Name = "PetIDDataGridViewTextBoxColumn"
        '
        'ApptTypeNumDataGridViewTextBoxColumn
        '
        Me.ApptTypeNumDataGridViewTextBoxColumn.DataPropertyName = "ApptTypeNum"
        Me.ApptTypeNumDataGridViewTextBoxColumn.HeaderText = "ApptTypeNum"
        Me.ApptTypeNumDataGridViewTextBoxColumn.Name = "ApptTypeNumDataGridViewTextBoxColumn"
        '
        'ApptDateDataGridViewTextBoxColumn
        '
        Me.ApptDateDataGridViewTextBoxColumn.DataPropertyName = "ApptDate"
        Me.ApptDateDataGridViewTextBoxColumn.HeaderText = "ApptDate"
        Me.ApptDateDataGridViewTextBoxColumn.Name = "ApptDateDataGridViewTextBoxColumn"
        '
        'NotesDataGridViewTextBoxColumn
        '
        Me.NotesDataGridViewTextBoxColumn.DataPropertyName = "Notes"
        Me.NotesDataGridViewTextBoxColumn.HeaderText = "Notes"
        Me.NotesDataGridViewTextBoxColumn.Name = "NotesDataGridViewTextBoxColumn"
        '
        'EstChargeDataGridViewTextBoxColumn
        '
        Me.EstChargeDataGridViewTextBoxColumn.DataPropertyName = "EstCharge"
        Me.EstChargeDataGridViewTextBoxColumn.HeaderText = "EstCharge"
        Me.EstChargeDataGridViewTextBoxColumn.Name = "EstChargeDataGridViewTextBoxColumn"
        '
        'ActualChargeDataGridViewTextBoxColumn
        '
        Me.ActualChargeDataGridViewTextBoxColumn.DataPropertyName = "ActualCharge"
        Me.ActualChargeDataGridViewTextBoxColumn.HeaderText = "ActualCharge"
        Me.ActualChargeDataGridViewTextBoxColumn.Name = "ActualChargeDataGridViewTextBoxColumn"
        '
        'NextApptDateDataGridViewTextBoxColumn
        '
        Me.NextApptDateDataGridViewTextBoxColumn.DataPropertyName = "NextApptDate"
        Me.NextApptDateDataGridViewTextBoxColumn.HeaderText = "NextApptDate"
        Me.NextApptDateDataGridViewTextBoxColumn.Name = "NextApptDateDataGridViewTextBoxColumn"
        '
        'VetTechNumDataGridViewTextBoxColumn
        '
        Me.VetTechNumDataGridViewTextBoxColumn.DataPropertyName = "VetTechNum"
        Me.VetTechNumDataGridViewTextBoxColumn.HeaderText = "VetTechNum"
        Me.VetTechNumDataGridViewTextBoxColumn.Name = "VetTechNumDataGridViewTextBoxColumn"
        '
        'AddNewButton
        '
        Me.AddNewButton.Location = New System.Drawing.Point(62, 291)
        Me.AddNewButton.Name = "AddNewButton"
        Me.AddNewButton.Size = New System.Drawing.Size(75, 23)
        Me.AddNewButton.TabIndex = 20
        Me.AddNewButton.Text = "Add New"
        Me.AddNewButton.UseVisualStyleBackColor = True
        '
        'SaveButton
        '
        Me.SaveButton.Location = New System.Drawing.Point(143, 291)
        Me.SaveButton.Name = "SaveButton"
        Me.SaveButton.Size = New System.Drawing.Size(75, 23)
        Me.SaveButton.TabIndex = 21
        Me.SaveButton.Text = "Save"
        Me.SaveButton.UseVisualStyleBackColor = True
        '
        'DeleteButton
        '
        Me.DeleteButton.Location = New System.Drawing.Point(224, 291)
        Me.DeleteButton.Name = "DeleteButton"
        Me.DeleteButton.Size = New System.Drawing.Size(75, 23)
        Me.DeleteButton.TabIndex = 22
        Me.DeleteButton.Text = "Delete"
        Me.DeleteButton.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(398, 391)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(57, 20)
        Me.Label1.TabIndex = 23
        Me.Label1.Text = "Label1"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(904, 450)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.DeleteButton)
        Me.Controls.Add(Me.SaveButton)
        Me.Controls.Add(Me.AddNewButton)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(ApptIDLabel)
        Me.Controls.Add(Me.ApptIDTextBox)
        Me.Controls.Add(PetIDLabel)
        Me.Controls.Add(Me.PetIDTextBox)
        Me.Controls.Add(ApptTypeNumLabel)
        Me.Controls.Add(Me.ApptTypeNumTextBox)
        Me.Controls.Add(ApptDateLabel)
        Me.Controls.Add(Me.ApptDateDateTimePicker)
        Me.Controls.Add(NotesLabel)
        Me.Controls.Add(Me.NotesTextBox)
        Me.Controls.Add(EstChargeLabel)
        Me.Controls.Add(Me.EstChargeTextBox)
        Me.Controls.Add(ActualChargeLabel)
        Me.Controls.Add(Me.ActualChargeTextBox)
        Me.Controls.Add(NextApptDateLabel)
        Me.Controls.Add(Me.NextApptDateDateTimePicker)
        Me.Controls.Add(VetTechNumLabel)
        Me.Controls.Add(Me.VetTechNumTextBox)
        Me.Controls.Add(Me.AppointmentBindingNavigator)
        Me.Name = "Form1"
        Me.Text = "Form1"
        CType(Me.FFDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.AppointmentBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.AppointmentBindingNavigator, System.ComponentModel.ISupportInitialize).EndInit()
        Me.AppointmentBindingNavigator.ResumeLayout(False)
        Me.AppointmentBindingNavigator.PerformLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents FFDataSet As FFDataSet
    Friend WithEvents AppointmentBindingSource As BindingSource
    Friend WithEvents AppointmentTableAdapter As FFDataSetTableAdapters.AppointmentTableAdapter
    Friend WithEvents TableAdapterManager As FFDataSetTableAdapters.TableAdapterManager
    Friend WithEvents AppointmentBindingNavigator As BindingNavigator
    Friend WithEvents BindingNavigatorAddNewItem As ToolStripButton
    Friend WithEvents BindingNavigatorCountItem As ToolStripLabel
    Friend WithEvents BindingNavigatorDeleteItem As ToolStripButton
    Friend WithEvents BindingNavigatorMoveFirstItem As ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem As ToolStripButton
    Friend WithEvents BindingNavigatorSeparator As ToolStripSeparator
    Friend WithEvents BindingNavigatorPositionItem As ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator1 As ToolStripSeparator
    Friend WithEvents BindingNavigatorMoveNextItem As ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem As ToolStripButton
    Friend WithEvents BindingNavigatorSeparator2 As ToolStripSeparator
    Friend WithEvents AppointmentBindingNavigatorSaveItem As ToolStripButton
    Friend WithEvents ApptIDTextBox As TextBox
    Friend WithEvents PetIDTextBox As TextBox
    Friend WithEvents ApptTypeNumTextBox As TextBox
    Friend WithEvents ApptDateDateTimePicker As DateTimePicker
    Friend WithEvents NotesTextBox As TextBox
    Friend WithEvents EstChargeTextBox As TextBox
    Friend WithEvents ActualChargeTextBox As TextBox
    Friend WithEvents NextApptDateDateTimePicker As DateTimePicker
    Friend WithEvents VetTechNumTextBox As TextBox
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents ApptIDDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents PetIDDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents ApptTypeNumDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents ApptDateDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents NotesDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents EstChargeDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents ActualChargeDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents NextApptDateDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents VetTechNumDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents AddNewButton As Button
    Friend WithEvents SaveButton As Button
    Friend WithEvents DeleteButton As Button
    Friend WithEvents Label1 As Label
End Class
