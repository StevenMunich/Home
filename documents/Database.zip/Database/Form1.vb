﻿Public Class Form1
    Private Sub AppointmentBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs) Handles AppointmentBindingNavigatorSaveItem.Click


        If ApptIDTextBox.Text = "" Then
            MessageBox.Show("Error: Appointment ID can not be null")
            Return
        End If

        Try
            Me.Validate()
            Me.AppointmentBindingSource.EndEdit()
            Me.TableAdapterManager.UpdateAll(Me.FFDataSet)
        Catch ex As Exception
            MessageBox.Show("Error: " + ex.ToString)
        End Try


    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'FFDataSet.Appointment' table. You can move, or remove it, as needed.
        Me.AppointmentTableAdapter.Fill(Me.FFDataSet.Appointment)

        'Row Count
        upDateRowCount()


    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles AddNewButton.Click
        AppointmentBindingSource.AddNew()

        'Auto- Primary Key
        ApptIDTextBox.Text = BindingNavigatorPositionItem.Text
        upDateRowCount()

    End Sub

    Private Sub SaveButton_Click(sender As Object, e As EventArgs) Handles SaveButton.Click


        Try
            AppointmentBindingSource.EndEdit()
            AppointmentTableAdapter.Update(FFDataSet)
            MsgBox("success")
        Catch ex As Exception
            MsgBox("Error: " + ex.ToString)
        End Try

        upDateRowCount()

    End Sub

    Private Sub DeleteButton_Click(sender As Object, e As EventArgs) Handles DeleteButton.Click
        AppointmentBindingSource.RemoveCurrent()
        upDateRowCount()
    End Sub

    'Update Row Count
    Private Sub upDateRowCount()
        Label1.Text = AppointmentBindingSource.Count
    End Sub


End Class
